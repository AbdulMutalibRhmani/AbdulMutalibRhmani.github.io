"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function References() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="references" className="py-20" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold">References</h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-2"></div>
        </motion.div>

        <Card className="max-w-3xl mx-auto">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground mb-6">
              Professional references are available upon request. Please feel free to contact me for reference
              information from previous employers and colleagues.
            </p>
            <Button className="mx-auto">
              <Download className="mr-2 h-4 w-4" /> Download CV
            </Button>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
