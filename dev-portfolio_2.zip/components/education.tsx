"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { GraduationCap, Award } from "lucide-react"

const education = [
  {
    type: "degree",
    title: "BSc in Software Engineering",
    institution: "Kabul University",
    period: "2012 - 2016",
    description:
      "Completed a comprehensive program in software engineering, covering programming, database management, software design, and project management.",
  },
  {
    type: "certification",
    title: "IT Certification",
    institution: "Kamgar Institute",
    period: "2015",
    description: "Specialized training in information technology fundamentals and practical applications.",
  },
  {
    type: "certification",
    title: "English Language Certification",
    institution: "Azrakhsh Center",
    period: "2014",
    description: "Advanced English language training focusing on technical and professional communication.",
  },
]

export default function Education() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="education" className="py-20 bg-white dark:bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Education</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-6">
          {education.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-[#f8fafc] dark:bg-gray-800 p-6 rounded-lg shadow-sm"
            >
              <div className="text-[#6366f1] mb-4">
                {item.type === "degree" ? <GraduationCap className="h-8 w-8" /> : <Award className="h-8 w-8" />}
              </div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{item.title}</h3>
              <p className="text-[#6366f1] font-medium">{item.institution}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{item.period}</p>
              <p className="text-gray-600 dark:text-gray-300">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
