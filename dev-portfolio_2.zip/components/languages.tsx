"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Progress } from "@/components/ui/progress"

const languages = [
  {
    name: "English",
    level: "Excellent",
    proficiency: 90,
  },
  {
    name: "Urdu",
    level: "Very Good",
    proficiency: 80,
  },
  {
    name: "Pashto",
    level: "Native",
    proficiency: 100,
  },
  {
    name: "Dari",
    level: "Fluent",
    proficiency: 95,
  },
  {
    name: "German",
    level: "Basic",
    proficiency: 30,
  },
]

export default function Languages() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="languages" className="py-20" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold">Languages</h2>
          <div className="w-20 h-1 bg-primary mx-auto mt-2"></div>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            My language proficiencies that enable me to communicate effectively in diverse environments.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {languages.map((language, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="mb-6"
            >
              <div className="flex justify-between mb-2">
                <h3 className="font-bold">{language.name}</h3>
                <span className="text-muted-foreground">{language.level}</span>
              </div>
              <Progress value={language.proficiency} className="h-2" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
