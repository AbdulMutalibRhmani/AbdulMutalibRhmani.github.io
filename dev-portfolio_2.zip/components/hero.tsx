"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Github, Linkedin, Mail, Facebook } from "lucide-react"
import { motion } from "framer-motion"
import Link from "next/link"
import Image from "next/image"

export default function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <section id="home" className="min-h-screen flex items-center py-20 bg-[#f8fafc] dark:bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              <span className="text-gray-800 dark:text-gray-100">Hi, I'm </span>
              <span className="text-[#6366f1]">Abdul Mutalib</span>
              <br />
              <span className="text-[#6366f1]">Rhmani</span>
            </h1>
            <h2 className="text-2xl font-medium text-gray-700 dark:text-gray-300 mb-4">Full Stack Developer</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-lg">
              I build exceptional digital experiences with cutting-edge technologies. Passionate about creating clean,
              efficient, and user-friendly applications.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button className="bg-[#6366f1] hover:bg-[#4f46e5] text-white rounded-md px-6" asChild>
                <Link href="#contact">Get In Touch</Link>
              </Button>
              <Button
                variant="outline"
                className="border-[#6366f1] text-[#6366f1] hover:bg-[#6366f1]/10 rounded-md px-6"
                asChild
              >
                <Link href="#projects">View My Work</Link>
              </Button>
            </div>
            <div className="flex gap-4 mt-8">
              <Link
                href="#"
                className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <Github className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                <span className="sr-only">GitHub</span>
              </Link>
              <Link
                href="#"
                className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <Linkedin className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                <span className="sr-only">LinkedIn</span>
              </Link>
              <Link
                href="#"
                className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <Facebook className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link
                href="#"
                className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                <Mail className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                <span className="sr-only">Email</span>
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative flex justify-center md:justify-end"
          >
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-white dark:border-gray-800 shadow-lg">
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Abdul Mutalib Rhmani"
                  width={400}
                  height={400}
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="absolute -right-4 bottom-4 bg-white dark:bg-gray-800 py-2 px-4 rounded-full shadow-md">
                <p className="text-sm font-medium text-[#6366f1]">7+ Years Experience</p>
              </div>
            </div>
          </motion.div>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce"
        >
          <Link href="#about" className="text-gray-400 hover:text-[#6366f1] transition-colors">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <path d="M12 5v14" />
              <path d="m19 12-7 7-7-7" />
            </svg>
            <span className="sr-only">Scroll down</span>
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
