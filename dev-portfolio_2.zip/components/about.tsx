"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">About Me</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-3xl mx-auto"
        >
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            I am a dedicated Full Stack Developer with extensive experience in software development, database
            administration, network administration, and leadership roles across various ministries and technology
            centers in Afghanistan.
          </p>
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            Throughout my career, I have had the privilege of working with high-level officials in government sectors,
            where I contributed to developing secure and scalable systems. I am particularly proud of my work in
            empowering female staff in government roles through technology training and mentorship.
          </p>
          <p className="text-gray-600 dark:text-gray-300">
            My technical expertise spans across PHP frameworks like Laravel and CodeIgniter, database management with
            MySQL, and front-end development using JavaScript libraries such as jQuery and Ajax. I am passionate about
            creating efficient, user-friendly applications that solve real-world problems.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
