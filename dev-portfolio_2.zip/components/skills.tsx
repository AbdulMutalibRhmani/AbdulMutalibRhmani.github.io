"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

const technicalSkills = [
  { name: "PHP", level: 90 },
  { name: "Laravel", level: 85 },
  { name: "CodeIgniter", level: 80 },
  { name: "MySQL", level: 85 },
  { name: "JavaScript", level: 75 },
  { name: "jQuery", level: 80 },
  { name: "Ajax", level: 75 },
  { name: "Java", level: 70 },
  { name: "HTML/CSS", level: 85 },
  { name: "Networking", level: 60 },
]

const softSkills = [
  { name: "Leadership", level: 90 },
  { name: "Communication", level: 85 },
  { name: "Teamwork", level: 90 },
  { name: "Problem Solving", level: 85 },
  { name: "Project Management", level: 80 },
  { name: "Cross-cultural Collaboration", level: 85 },
]

export default function Skills() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="skills" className="py-20 bg-[#f8fafc] dark:bg-gray-950" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Skills</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">Technical Skills</h3>
            <div className="grid md:grid-cols-2 gap-x-10 gap-y-6">
              {technicalSkills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                >
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-700 dark:text-gray-300 font-medium">{skill.name}</span>
                    <span className="text-gray-500 dark:text-gray-400 text-sm">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-[#6366f1] h-2 rounded-full" style={{ width: `${skill.level}%` }}></div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">Soft Skills</h3>
            <div className="grid md:grid-cols-2 gap-x-10 gap-y-6">
              {softSkills.map((skill, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                  transition={{ duration: 0.5, delay: index * 0.05 + 0.5 }}
                >
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-700 dark:text-gray-300 font-medium">{skill.name}</span>
                    <span className="text-gray-500 dark:text-gray-400 text-sm">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-[#6366f1] h-2 rounded-full" style={{ width: `${skill.level}%` }}></div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
