"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Award } from "lucide-react"

const certifications = [
  {
    title: "IT Certification",
    organization: "Kamgar Institute",
    date: "2015",
    description: "Comprehensive IT training covering software development, database management, and networking.",
  },
  {
    title: "English Language Certification",
    organization: "Azrakhsh Center",
    date: "2014",
    description: "Advanced English language proficiency certification with focus on technical communication.",
  },
  {
    title: "Web Development",
    organization: "ITCK",
    date: "2016",
    description: "Specialized training in web development technologies including PHP, MySQL, and JavaScript.",
  },
]

export default function Certifications() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="certifications" className="py-20 bg-[#f8fafc] dark:bg-gray-950" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Certifications</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto grid md:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm"
            >
              <div className="text-[#6366f1] mb-4">
                <Award className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{cert.title}</h3>
              <p className="text-[#6366f1] font-medium">{cert.organization}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{cert.date}</p>
              <p className="text-gray-600 dark:text-gray-300">{cert.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
