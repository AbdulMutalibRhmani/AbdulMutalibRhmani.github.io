"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import Image from "next/image"
import { Github, ExternalLink } from "lucide-react"
import Link from "next/link"

const projects = [
  {
    title: "Ministry of Transport System",
    description:
      "Developed a comprehensive management system for the Ministry of Transport and Aviation to streamline operations and improve data management.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Laravel", "MySQL", "jQuery", "Bootstrap"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    title: "NSAI Management Platform",
    description: "Built a custom management platform for NSAI to handle internal processes and data management.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["PHP", "MySQL", "JavaScript", "CSS"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    title: "ADRAS Management System",
    description:
      "Built a comprehensive management system for ADRAS to handle project tracking, resource allocation, and reporting.",
    image: "/placeholder.svg?height=400&width=600",
    tags: ["PHP", "MySQL", "jQuery", "CSS"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    title: "ITCK Training Platform",
    description:
      'Developed an educational platform for ITCK to facilitate online learning, course management, "Developed an educational platform for ITCK to facilitate online learning, course management, and student progress tracking.',
    image: "/placeholder.svg?height=400&width=600",
    tags: ["Java", "MySQL", "JavaScript", "HTML/CSS"],
    githubUrl: "#",
    liveUrl: "#",
  },
]

export default function Projects() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="projects" className="py-20 bg-white dark:bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Projects</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-[#f8fafc] dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm"
            >
              <div className="relative h-48 w-full">
                <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">{project.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs px-3 py-1 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex gap-4">
                  <Link
                    href={project.githubUrl}
                    className="flex items-center text-gray-700 dark:text-gray-300 hover:text-[#6366f1] dark:hover:text-[#6366f1] text-sm"
                  >
                    <Github className="h-4 w-4 mr-1" />
                    Code
                  </Link>
                  <Link
                    href={project.liveUrl}
                    className="flex items-center text-gray-700 dark:text-gray-300 hover:text-[#6366f1] dark:hover:text-[#6366f1] text-sm"
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    Live Demo
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
