"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

const experiences = [
  {
    title: "Senior Software Developer",
    company: "Ministry of Transport and Aviation",
    period: "Jan 2023 – Apr 2023",
    description:
      "Developed and maintained software systems for the ministry, focusing on improving operational efficiency and data security.",
    responsibilities: [
      "Led the development of custom software solutions",
      "Implemented secure database systems for sensitive government data",
      "Collaborated with ministry officials to understand and address specific needs",
    ],
  },
  {
    title: "Software Developer",
    company: "NSAI",
    period: "Jul 2020 – Aug 2021",
    description: "Developed and maintained software applications for organizational needs.",
    responsibilities: [
      "Built custom software solutions using PHP and MySQL",
      "Implemented user interfaces with JavaScript and jQuery",
      "Collaborated with team members to ensure project success",
    ],
  },
  {
    title: "Software Developer",
    company: "ADRAS",
    period: "Mar 2019 – Oct 2019",
    description:
      "Built custom software solutions for organizational needs, focusing on efficiency and user experience.",
    responsibilities: [
      "Developed web-based applications using PHP and MySQL",
      "Implemented front-end interfaces with JavaScript and jQuery",
      "Collaborated with cross-functional teams to deliver projects on time",
    ],
  },
  {
    title: "Software Developer",
    company: "ITCK (Information Technology Center of Kabul)",
    period: "Apr 2016 – Jan 2019",
    description: "Developed educational software and platforms for IT training and education.",
    responsibilities: [
      "Created learning management systems for IT courses",
      "Developed student tracking and assessment tools",
      "Maintained and updated existing software systems",
    ],
  },
  {
    title: "HCN Trainer & Linguist",
    company: "VBS",
    period: "Oct 2019 – May 2020",
    description: "Provided language training and cultural guidance, facilitating cross-cultural communication.",
    responsibilities: [
      "Conducted language training sessions",
      "Provided cultural context and guidance",
      "Facilitated effective communication between diverse teams",
    ],
  },
  {
    title: "MoneyGram Officer",
    company: "Buloro Afghanistan",
    period: "Jun 2022 – Dec 2022",
    description: "Managed financial transactions and customer service for international money transfers.",
    responsibilities: [
      "Processed international money transfers",
      "Ensured compliance with financial regulations",
      "Provided excellent customer service",
    ],
  },
]

export default function Experience() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="experience" className="py-20 bg-[#f8fafc] dark:bg-gray-950" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Experience</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="mb-10 relative pl-8 border-l-2 border-gray-200 dark:border-gray-700"
            >
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-[#6366f1]"></div>
              <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-gray-800 dark:text-white">{exp.title}</h3>
                <p className="text-[#6366f1] font-medium">{exp.company}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{exp.period}</p>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{exp.description}</p>
                <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                  {exp.responsibilities.map((resp, respIndex) => (
                    <li key={respIndex}>{resp}</li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
