import Link from "next/link"

export default function Footer() {
  return (
    <footer className="py-8 bg-[#f8fafc] dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link href="/" className="text-xl font-bold text-[#6366f1]">
              Rhmani.dev
            </Link>
          </div>
          <div className="flex flex-wrap justify-center gap-6">
            <Link
              href="#home"
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#6366f1] dark:hover:text-[#6366f1] transition-colors"
            >
              Home
            </Link>
            <Link
              href="#about"
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#6366f1] dark:hover:text-[#6366f1] transition-colors"
            >
              About
            </Link>
            <Link
              href="#experience"
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#6366f1] dark:hover:text-[#6366f1] transition-colors"
            >
              Experience
            </Link>
            <Link
              href="#projects"
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#6366f1] dark:hover:text-[#6366f1] transition-colors"
            >
              Projects
            </Link>
            <Link
              href="#contact"
              className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#6366f1] dark:hover:text-[#6366f1] transition-colors"
            >
              Contact
            </Link>
          </div>
        </div>
        <div className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>© {new Date().getFullYear()} Abdul Mutalib Rhmani. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
