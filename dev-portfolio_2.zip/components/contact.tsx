"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Mail, Phone, Github, Linkedin, Facebook } from "lucide-react"
import Link from "next/link"

export default function Contact() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="contact" className="py-20 bg-white dark:bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Contact</h2>
          <div className="w-20 h-1 bg-[#6366f1] mx-auto mt-2"></div>
        </motion.div>

        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">Get In Touch</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-8">
              Feel free to reach out if you have any questions or would like to discuss potential opportunities. I'm
              always open to new projects and collaborations.
            </p>

            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-[#6366f1]/10 p-3 rounded-full mr-4">
                  <MapPin className="h-5 w-5 text-[#6366f1]" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">Location</h4>
                  <p className="text-gray-600 dark:text-gray-300">Afghanistan</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-[#6366f1]/10 p-3 rounded-full mr-4">
                  <Mail className="h-5 w-5 text-[#6366f1]" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">Email</h4>
                  <p className="text-gray-600 dark:text-gray-300">abdulmotalib946@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-[#6366f1]/10 p-3 rounded-full mr-4">
                  <Phone className="h-5 w-5 text-[#6366f1]" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">Phone</h4>
                  <p className="text-gray-600 dark:text-gray-300">+93 788628025 (WhatsApp)</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <h4 className="font-medium text-gray-800 dark:text-white mb-4">Follow Me</h4>
              <div className="flex space-x-4">
                <Link
                  href="#"
                  className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-[#6366f1]/10 transition-colors"
                >
                  <Github className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                  <span className="sr-only">GitHub</span>
                </Link>
                <Link
                  href="#"
                  className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-[#6366f1]/10 transition-colors"
                >
                  <Linkedin className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                  <span className="sr-only">LinkedIn</span>
                </Link>
                <Link
                  href="#"
                  className="bg-gray-100 dark:bg-gray-800 p-2 rounded-full hover:bg-[#6366f1]/10 transition-colors"
                >
                  <Facebook className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                  <span className="sr-only">Facebook</span>
                </Link>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-[#f8fafc] dark:bg-gray-800 p-6 rounded-lg shadow-sm"
          >
            <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-6">Send Me a Message</h3>
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Name
                  </label>
                  <Input
                    id="name"
                    placeholder="Your name"
                    className="w-full bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Your email"
                    className="w-full bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Subject
                </label>
                <Input
                  id="subject"
                  placeholder="Subject"
                  className="w-full bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Message
                </label>
                <Textarea
                  id="message"
                  placeholder="Your message"
                  rows={5}
                  className="w-full bg-white dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                />
              </div>
              <Button type="submit" className="w-full bg-[#6366f1] hover:bg-[#4f46e5] text-white">
                Send Message
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
